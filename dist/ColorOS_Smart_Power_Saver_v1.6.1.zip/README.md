# ColorOS Smart Screen-Off Power Saver v1.6.1

100% 用户态实现，只调用 Android 系统省电模式（`cmd power set-mode 1/0`）。
不调整 CPU 频率、不修改内核参数、不替换系统文件、不持有 wakelock。

## 行为规则

1. 息屏延迟规则（电量在息屏那一刻取样，优先级从高到低）：
   - 电量 < 45% → 延迟 120 秒（2 分钟），不再计算亮屏时长；
   - 电量 >= 45% 时按本次亮屏时长判断（墙钟时间）：
     - 亮屏不足 5 分钟 → 延迟 120 秒（2 分钟）；
     - 亮屏满 5 分钟及以上 → 延迟 240 秒（4 分钟）；
     - 亮屏时长无法判定 → 按 240 秒（保守）。
   息屏期间插电/掉电不会改变已定的延时。
2. 延迟到期且仍处于息屏状态时，执行 `cmd power set-mode 1` 进入系统省电模式。
3. 亮屏时立即取消待触发的倒计时；如果当前省电模式是**本模块开启的**，亮屏保持 5 秒后才执行 `cmd power set-mode 0` 关闭；
   若这 5 秒内又息屏，则保持省电不动（短暂亮屏不会打断省电）。
4. 充电/供电状态下息屏不触发（`AC/USB/Wireless/Dock powered: true` 均视为供电）。
5. 若息屏前省电模式已由用户或系统开启，模块全程不接管、不关闭。
6. 兜底轮询：模块持有省电（`on:*`）时每 120 秒检查一次；其余时间每 300 秒检查一次。
   轮询同时检测亮灭屏跳变，因此即使 ROM 不上报 `screen_toggled` 事件，模块仍能工作（触发延迟最多增加一个轮询周期）。
7. 自动开启计数：只有“本模块成功开启并验证生效”才累计 +1；关闭、开启失败、系统自己开启的都不计数。

## 实现要点

- `service.sh` 在 Magisk/KernelSU/APatch 的 late_start service 阶段运行，后台常驻，不阻塞启动。
- 先等待 `sys.boot_completed=1` 再启动守护逻辑。
- 屏幕状态来自 events 缓冲区 `screen_toggled`（`finishedGoingToSleep` 写 0，`startedWakingUp` 写 1），解析失败时回退到 `dumpsys power`。
- 监听进程带自愈：logcat 管道退出后按 30/60/120/300 秒退避自动重启，退出前把 stderr 写入 `logcat.err` 并写日志，避免静默失效。
- 监听使用 `logcat -T 1`：只回放最后一条事件后开始实时跟随，避免重启时把 events 缓冲区里的旧事件全部重放。
- 跨进程状态保存在 `/data/adb/coloros_smart_power_saver/state`：
  - `off`：模块不持有省电状态；
  - `pending:<token>`：息屏延迟计时中；
  - `on:<原sticky值>`：当前省电模式由本模块开启。
- 只有 `on:*` 状态允许模块调用 `set-mode 0`，避免误关用户手动开启的省电。
- 取消延迟使用令牌比对，不按 PID `kill`，避免 PID 复用误杀和孤儿进程。
- 延迟采用 `date +%s` 墙钟分片检查（每片最多 60 秒），计时不受 `CLOCK_MONOTONIC` 不计挂起时间的影响；一次 2~5 分钟倒计时最多产生数次定时器唤醒，不持有 wakelock。
- `cmd power set-mode 1` 会顺带置位 `low_power_sticky`，模块会暂时清零以避免拔充电后自动复活，关闭时恢复原值。
- 状态文件采用临时文件 + `mv` 原子替换，进程被中断也不会写出半截状态。
- 日志超过 512 KB 自动轮转为 `service.log.1`，最多保留两份。
- 累计次数写在 `count`，每次开启明细写在 `history.log`（时间 / 电量 / 延时 / 第几次），超过 512 KB 轮转为 `.1`。
- 开启/关闭后采用最多 10 秒的轮询回读（每秒一次），兼容部分 ROM 上 `cmd power set-mode` 异步生效的情况，避免误判失败。

## 文件与日志

- 运行状态目录：`/data/adb/coloros_smart_power_saver/`
- 日志：`/data/adb/coloros_smart_power_saver/service.log`（可在模块目录内手动清空）
- 计数：`cat /data/adb/coloros_smart_power_saver/count`（重置：`echo 0 > /data/adb/coloros_smart_power_saver/count`）
- 明细：`/data/adb/coloros_smart_power_saver/history.log`
- 模块不写入任何系统分区；卸载脚本只删除自身运行状态目录。

## 已知限制

- 依赖系统支持 `cmd power set-mode`（Android 10+ 及 ColorOS 均可，个别机型可能被裁剪）。
- `dumpsys`/`settings`/`cmd` 需要 root，Magisk/KernelSU/APatch 环境满足。
- 亮屏恢复延迟为“事件触发 + 一次 `settings` 查询 + 一次 `set-mode`”的量级，通常数百毫秒，不是毫秒级。
- 模块通过 `low_power` 判断省电状态；若 ColorOS 使用独立省电实现而不写入该设置，需要实机确认。
- 若 ROM 不上报 `screen_toggled`，模块退化为 300 秒轮询检测，功能可用但息屏延迟计时会晚一个轮询周期开始。

## 实机自检

```sh
# 1. 屏幕亮灭事件是否上报
logcat -b events -v raw -s screen_toggled

# 2. 省电状态读写是否一致
settings get global low_power
cmd power set-mode 1; settings get global low_power; cmd power set-mode 0

# 3. 守护日志
cat /data/adb/coloros_smart_power_saver/service.log
```
